"""
Main entry point for the MHA Toolbox CLI.
Usage: python -m mha_toolbox <command> [args]
"""

from .cli import main

if __name__ == '__main__':
    main()